# Universal NGS Analysis (Streamlit)

Paired-end Illumina → QC → trimming → de novo (SPAdes) and/or reference-guided (Bowtie2 + bcftools, iterative, N-masked)
→ BLAST → phylogeny + amino-acid changes → Excel/figures → NCBI submission files.
For **small genomes** (viruses, plasmids, organelles, amplicons, small bacteria for assembly/mapping).

## Run it
**Docker (recommended – bundles every tool):**
    docker build -t ngs-app .
    docker run -p 8501:8501 -v $PWD/ngs_runs:/data/ngs_runs ngs-app
    # open http://localhost:8501

**Local (Ubuntu/Debian):**
    sudo apt-get install $(cat packages.txt)
    pip install -r requirements.txt
    streamlit run app.py

Needs ≥ 8 GB RAM for SPAdes on typical viral data; BLAST/GenBank steps need internet.
Streamlit Community Cloud is too small for assembly; use a VM/Docker host (or a Docker-based Space).
Runs are stored under `NGS_RUNS_DIR` (default `./ngs_runs`) and can be re-opened from the sidebar.
