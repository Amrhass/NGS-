import json, os, traceback, uuid
from pathlib import Path

import pandas as pd
import streamlit as st

import ngs_core as core

st.set_page_config(page_title="Universal NGS Analysis", page_icon="🧬", layout="wide")
BASE = Path(os.environ.get("NGS_RUNS_DIR", "ngs_runs"))
BASE.mkdir(parents=True, exist_ok=True)
SID = st.session_state.setdefault("sid", uuid.uuid4().hex[:8])
UP_DIR = BASE / "uploads" / SID
SAMPLE_TYPES = ["RNA virus", "DNA virus / bacterium / isolate", "Metagenome / mixed sample", "General (careful)"]


def table(rows, **kw):
    if rows:
        st.dataframe(pd.DataFrame(rows), width="stretch", hide_index=True, **kw)
    else:
        st.caption("no data")


def dl(label, path, key, mime=None):
    p = Path(path)
    if p.exists():
        st.download_button(label, p.read_bytes(), file_name=p.name, mime=mime, key=key)


def current_run():
    rp = st.session_state.get("run_path")
    if rp and (Path(rp) / "run.json").exists():
        return core.load_run(rp)
    return None


# ------------------------------------------------------------------ sidebar
with st.sidebar:
    st.title("🧬 NGS Analysis")
    st.caption("Universal paired-end Illumina analysis for small genomes: viruses, plasmids, organelles, amplicons, small bacteria.")
    prev = ["— new analysis —"] + core.list_runs(BASE)
    choice = st.selectbox("Open a previous run", prev, key="prev_run")
    if choice != prev[0]:
        st.session_state["run_path"] = str(BASE / choice)
    st.subheader("Settings")
    sample_type = st.selectbox("Sample type (selects SPAdes mode)", SAMPLE_TYPES, key="p_type")
    threads = st.number_input("Threads", 1, 64, min(4, os.cpu_count() or 4), key="p_threads")
    adapter = st.selectbox("Adapter set", ["TruSeq3-PE-2.fa", "TruSeq3-PE.fa", "NexteraPE-PE.fa"], key="p_adapter")
    min_read_len = st.number_input("Min read length after trimming", 20, 200, 36, key="p_minlen")
    min_depth = st.number_input("Min depth for consensus (below → N)", 1, 1000, 10, key="p_depth")
    min_qual = st.number_input("Min variant QUAL", 0, 200, 30, key="p_qual")
    min_alt = st.slider("Min alt-allele fraction (majority = 0.5)", 0.1, 1.0, 0.5, 0.05, key="p_alt")
    iters = st.number_input("Reference-guided refinement rounds", 1, 5, 2, key="p_iters")
    min_contig_len = st.number_input("De novo: min contig length", 50, 100000, 200, key="p_clen")
    min_contig_cov = st.number_input("De novo: min contig k-mer coverage", 0.0, 1000.0, 5.0, key="p_ccov")
    with st.expander("Installed tools"):
        for k, v in core.tool_status().items():
            st.write(("✅ " if v else "❌ ") + k)
PARAMS = dict(threads=int(threads), adapter_file=adapter, min_read_len=int(min_read_len), sample_type=sample_type,
              min_depth=int(min_depth), min_variant_qual=int(min_qual), min_alt_fraction=float(min_alt),
              ref_iterations=int(iters), min_contig_len=int(min_contig_len), min_contig_cov=float(min_contig_cov))

tabs = st.tabs(["1 · Data", "2 · Run", "3 · Results", "4 · BLAST", "5 · Phylogeny & mutations", "6 · Export & NCBI"])

# ------------------------------------------------------------------ 1 Data
with tabs[0]:
    st.header("Input data")
    mode = st.radio("Reads source", ["Upload FASTQ files", "Folder on the server"], horizontal=True, key="src_mode")
    reads_dir = None
    if mode == "Upload FASTQ files":
        files = st.file_uploader("Paired-end FASTQ (R1 + R2, .fastq/.fq/.gz)", accept_multiple_files=True,
                                 type=["fastq", "fq", "gz"], key="reads_up")
        if files:
            UP_DIR.mkdir(parents=True, exist_ok=True)
            for f in files:
                dst = UP_DIR / f.name
                if not dst.exists() or dst.stat().st_size != f.size:
                    dst.write_bytes(f.getbuffer())
            reads_dir = str(UP_DIR)
    else:
        reads_dir = st.text_input("Folder containing the FASTQ files", key="reads_dir")
    pairs = core.find_pairs(reads_dir) if reads_dir and os.path.isdir(reads_dir) else {}
    sample = None
    if pairs:
        sample = st.selectbox("Sample", list(pairs), key="sample_sel")
        st.success(f"{len(pairs)} paired sample(s) detected. R1: {os.path.basename(pairs[sample][0])} · R2: {os.path.basename(pairs[sample][1])}")
    elif reads_dir:
        st.warning("No complete R1/R2 pair found (expected names like *_R1_001.fastq.gz / *_R2_001.fastq.gz, *_R1.fq.gz, *_1.fastq.gz).")

    st.subheader("Reference (needed for reference-guided; optional for de novo/QUAST)")
    rmode = st.radio("Reference", ["None", "Upload FASTA", "Path on the server"], horizontal=True, key="ref_mode")
    ref_path = None
    if rmode == "Upload FASTA":
        rf = st.file_uploader("Reference FASTA (one or several sequences)", type=["fa", "fasta", "fna", "txt"], key="ref_up")
        if rf:
            UP_DIR.mkdir(parents=True, exist_ok=True)
            ref_path = str(UP_DIR / ("reference_" + rf.name)); Path(ref_path).write_bytes(rf.getbuffer())
    elif rmode == "Path on the server":
        p = st.text_input("Reference FASTA path", key="ref_path")
        ref_path = p if p and os.path.isfile(p) else None
    workflows = st.multiselect("Workflows to run", ["Reference-guided", "De novo"],
                               default=["Reference-guided", "De novo"] if ref_path else ["De novo"],
                               key=f"workflows_{'ref' if ref_path else 'noref'}")

# ------------------------------------------------------------------ 2 Run
with tabs[1]:
    st.header("Run the pipeline")
    ready = bool(sample) and bool(workflows) and not ("Reference-guided" in workflows and not ref_path)
    if not sample:
        st.info("Provide paired reads in tab 1.")
    elif "Reference-guided" in workflows and not ref_path:
        st.warning("Reference-guided needs a reference FASTA (tab 1) – or untick it.")
    if st.button("▶ Start analysis", type="primary", disabled=not ready, key="start"):
        lines = []
        box = st.empty()
        def logfn(m):
            lines.append(m); box.code("\n".join(lines[-18:]), language=None)
        try:
            with st.status("Running QC → trimming → assembly ...", expanded=True) as status:
                run = core.new_run(BASE, sample, PARAMS, logfn)
                clean_ref = None
                if ref_path:
                    clean_ref = str(run.dir / "reference_cleaned.fasta")
                    recs = core.clean_reference(ref_path, clean_ref)
                    logfn(f"Reference OK: {len(recs)} sequence(s)")
                r1, r2 = pairs[sample]
                core.step_qc_trim(run, r1, r2, clean_ref)
                if "De novo" in workflows:
                    core.step_denovo(run)
                if "Reference-guided" in workflows:
                    core.step_refguided(run)
                run.data["workflows"] = workflows; run.save()
                st.session_state["run_path"] = str(run.dir)
                status.update(label="✅ Finished – open tab 3 · Results", state="complete")
        except Exception as e:
            st.error(f"Pipeline stopped: {e}")
            with st.expander("Technical details"):
                st.code(traceback.format_exc())
    cur = current_run()
    if cur:
        st.caption(f"Active run: {cur.dir}")

# ------------------------------------------------------------------ 3 Results
with tabs[2]:
    run = current_run()
    if not run:
        st.info("No run loaded yet – start an analysis (tab 2) or open a previous run in the sidebar.")
    else:
        d, P = run.data, run.params
        st.header(f"Results – {run.sample}  ({d['run_id']})")
        t_sum, t_qc, t_dn, t_rg, t_cs = st.tabs(["Summary", "QC & trimming", "De novo", "Reference-guided", "Consensus"])
        with t_sum:
            tr = d.get("trim", {})
            c = st.columns(3)
            c[0].metric("Read pairs", f"{tr.get('input_pairs', 0):,}")
            c[1].metric("Surviving trimming", f"{tr.get('both_surviving', 0):,}", f"{tr.get('both_surviving_pct')}%")
            warn, rows = [], []
            if tr.get("both_surviving_pct", 100) < 70:
                warn.append("Less than 70% of read pairs survived trimming (check adapter set / read quality).")
            if "refguided" in d:
                g = d["refguided"]; c[2].metric("Reads aligned to final consensus", f"{g['verify_mapping']['overall_alignment_rate']}%")
                for x in g["records"]:
                    rows.append({"workflow": "reference-guided", **x})
                    if x["N_percent"] > 5: warn.append(f"[ref-guided] {x['id']} has {x['N_percent']}% N (low coverage).")
                if g["residual_variants"]: warn.append(f"[ref-guided] {len(g['residual_variants'])} residual variant(s) after verification.")
            if "denovo" in d:
                x_ = d["denovo"]
                for x in x_["records"]:
                    rows.append({"workflow": "de novo", **x})
                    if x["mean_depth"] < P["min_depth"]: warn.append(f"[de novo] {x['id']} mean depth below {P['min_depth']}x.")
            table(rows)
            for w in warn: st.warning(w)
            if not warn: st.success("No warnings.")
        with t_qc:
            def qc(rows):
                out = []
                for r in rows or []:
                    o = {"file": r["file"], "reads": r["total_sequences"], "length": r["length"], "%GC": r["gc"]}
                    for k in ("Per base sequence quality", "Per sequence quality scores", "Adapter Content", "Overrepresented sequences"):
                        o[k] = r["status"].get(k, "")
                    out.append(o)
                return out
            st.subheader("Raw reads (FastQC)"); table(qc(d.get("qc_raw")))
            st.subheader("Trimmomatic"); table([d.get("trim", {})])
            st.subheader("Trimmed reads (FastQC)"); table(qc(d.get("qc_trim")))
        with t_dn:
            if "denovo" not in d: st.info("De novo workflow was not run.")
            else:
                x = d["denovo"]
                st.caption(f"SPAdes mode: {x['mode']} · {x['n_kept']} contig(s) kept")
                st.subheader("SPAdes contigs"); table(x["contigs_table"])
                st.subheader("Final contigs with read-back coverage"); table(x["records"])
                img = core.depth_png(json.load(open(x["depth_json"])), "De novo – read depth", P["min_depth"])
                if img: st.image(img)
                if x["quast"]:
                    with st.expander("QUAST metrics"): table(x["quast"])
        with t_rg:
            if "refguided" not in d: st.info("Reference-guided workflow was not run.")
            else:
                g = d["refguided"]
                st.subheader("Refinement rounds"); table(g["iterations"])
                st.subheader("Final consensus statistics"); table(g["records"])
                st.subheader(f"Variants vs original reference: {len(g['variants_vs_reference'])}"); table(g["variants_vs_reference"])
                st.subheader(f"Verification – residual variants: {len(g['residual_variants'])}")
                if g["residual_variants"]: table(g["residual_variants"])
                img = core.depth_png(json.load(open(g["depth_json"])), "Reference-guided – read depth", P["min_depth"])
                if img: st.image(img)
        with t_cs:
            for key, label in (("refguided", "Reference-guided"), ("denovo", "De novo")):
                if key in d:
                    f = d[key]["consensus"]
                    st.subheader(label)
                    dl(f"⬇ {Path(f).name}", f, f"dl_{key}")
                    st.code("".join(f">{n}\n{s}\n" for n, s in core.parse_fasta(f))[:20000], language=None)

# ------------------------------------------------------------------ 4 BLAST
with tabs[3]:
    run = current_run()
    st.header("BLAST consensus sequences against NCBI")
    if not run: st.info("Load or create a run first.")
    else:
        avail = [k for k in ("refguided", "denovo") if k in run.data]
        src = st.multiselect("Sequences to search", avail, default=avail, key="bl_src",
                             format_func=lambda k: {"refguided": "Reference-guided", "denovo": "De novo"}[k])
        c = st.columns(4)
        db = c[0].selectbox("Database", ["nt", "core_nt", "refseq_representative_genomes"], key="bl_db")
        top = c[1].number_input("Top hits per sequence", 1, 50, 10, key="bl_top")
        maxq = c[2].number_input("Max sequences", 1, 100, 20, key="bl_maxq")
        maxlen = c[3].number_input("Max query length (bp)", 1000, 200000, 30000, key="bl_maxlen")
        ent = st.text_input("Optional Entrez filter (empty = universal search), e.g. Betacoronavirus[Organism]", key="bl_ent")
        st.caption("Remote NCBI BLAST (megablast). Expect ~1–5 min per sequence; needs internet from the server.")
        if st.button("🔎 Run BLAST", disabled=not src, key="bl_go"):
            lines = []; box = st.empty()
            run.logfn = lambda m: (lines.append(m), box.code("\n".join(lines[-12:]), language=None))
            try:
                with st.spinner("Searching NCBI ..."):
                    core.step_blast(run, tuple(src), db, ent, int(top), int(maxlen), int(maxq))
                st.rerun()
            except Exception as e:
                st.error(str(e))
        run = current_run()
        b = run.data.get("blast")
        if b:
            rows = b["rows"]
            for r in rows: r["link"] = f"https://www.ncbi.nlm.nih.gov/nucleotide/{r['accession']}"
            st.subheader("Best hit per sequence")
            if rows:
                st.dataframe(pd.DataFrame([r for r in rows if r["rank"] == 1]), hide_index=True, width="stretch",
                             column_config={"link": st.column_config.LinkColumn("NCBI", display_text="open")})
                with st.expander("All hits"): table(rows)
            for e in b["errors"]: st.warning(e)

# ------------------------------------------------------------------ 5 Phylogeny
with tabs[4]:
    run = current_run()
    st.header("Phylogeny + amino-acid changes")
    if not run: st.info("Load or create a run first.")
    elif not (run.data.get("blast") or {}).get("rows"): st.info("Run BLAST first (tab 4) – its hits are used as comparison sequences.")
    else:
        avail = [k for k in ("refguided", "denovo") if k in run.data]
        src = st.multiselect("Sequences", avail, default=avail[:1], key="ph_src",
                             format_func=lambda k: {"refguided": "Reference-guided", "denovo": "De novo"}[k])
        c = st.columns(3)
        method = c[0].selectbox("Tree method", ["iqtree", "fasttree"], key="ph_method")
        hits = c[1].number_input("Comparison sequences per query", 3, 50, 10, key="ph_hits")
        boots = c[2].number_input("Bootstraps (min 1000)", 1000, 10000, 1000, key="ph_boots")
        email = st.text_input("Your email (NCBI asks for it for downloads)", key="ph_email")
        extra = st.text_input("Extra GenBank accessions to include (comma-separated, optional)", key="ph_extra")
        markers = st.text_area("Marker positions to check (optional). One per line:  gene|alt-name ; position ; concerning amino acid ; note",
                               placeholder="PB2|polymerase basic protein 2 ; 627 ; K ; example marker", key="ph_markers")
        st.caption("Positions refer to the protein numbering of the annotated best hit (Met = 1). Whole-genome alignments above 100 kb are skipped.")
        if st.button("🌳 Run phylogeny + mutation analysis", disabled=not src, key="ph_go"):
            lines = []; box = st.empty()
            run.logfn = lambda m: (lines.append(m), box.code("\n".join(lines[-12:]), language=None))
            try:
                with st.spinner("Downloading references, aligning, building trees ..."):
                    core.step_phylo(run, tuple(src), method, int(hits), int(boots), extra, email, "", markers)
                st.rerun()
            except Exception as e:
                st.error(str(e)); st.code(traceback.format_exc())
        run = current_run()
        p = run.data.get("phylo")
        if p:
            st.subheader("Nucleotide identity to best GenBank hit"); table(p["identity"])
            st.subheader("Per-protein amino-acid summary"); table(p["genes"])
            if p["markers"]: st.subheader("Marker positions"); table(p["markers"])
            with st.expander(f"All amino-acid changes ({len(p['substitutions'])})"): table(p["substitutions"])
            for g in p["groups"]:
                st.subheader(g["query"]); st.caption(f"{g['method']} · {g['n_sequences']} sequences")
                if g.get("tree_png") and os.path.exists(g["tree_png"]): st.image(g["tree_png"])
            for s_ in p.get("skipped", []): st.warning(s_)

# ------------------------------------------------------------------ 6 Export
with tabs[5]:
    run = current_run()
    st.header("Export & NCBI submission package")
    if not run: st.info("Load or create a run first.")
    else:
        st.subheader("Supplementary tables + figures")
        if st.button("📑 Build Excel + figures", key="xl_go"):
            try:
                st.session_state["xlsx"] = core.step_export_excel(run)
            except Exception as e:
                st.error(str(e))
        if st.session_state.get("xlsx") and Path(st.session_state["xlsx"]).exists():
            dl("⬇ supplementary_tables.xlsx", st.session_state["xlsx"], "dl_xlsx")
        st.divider()
        st.subheader("Prepare files for NCBI (GenBank + BioSample + SRA)")
        st.caption("This builds the files; it cannot submit for you. Submission needs your NCBI account at https://submit.ncbi.nlm.nih.gov/ .")
        avail = [k for k, l in (("refguided", "reference_guided"), ("denovo", "de_novo")) if k in run.data]
        if not avail: st.info("Run an assembly workflow first.")
        else:
            srcname = st.radio("Sequences to submit", [{"refguided": "reference_guided", "denovo": "de_novo"}[k] for k in avail], horizontal=True, key="nc_src")
            maxn = st.number_input("Max N % allowed", 0.0, 50.0, 5.0, key="nc_maxn")
            c = st.columns(2)
            organism = c[0].text_input("Organism (scientific name)", key="nc_org")
            namef = c[1].selectbox("Name field", ["strain", "isolate"], key="nc_namef")
            c = st.columns(3)
            strain = c[0].text_input("Strain / isolate name", key="nc_strain")
            host = c[1].text_input("Host", key="nc_host")
            country = c[2].text_input("Country", key="nc_country")
            c = st.columns(3)
            date = c[0].text_input("Collection date (YYYY-MM-DD)", key="nc_date")
            isosrc = c[1].text_input("Isolation source (optional)", key="nc_iso")
            bioproj = c[2].text_input("BioProject accession (optional)", key="nc_bp")
            gextra = st.text_area("Extra source modifiers for ALL sequences (key=value per line, optional) e.g. segment, serotype, genotype",
                                  key="nc_gextra")
            c = st.columns(4)
            strat = c[0].selectbox("Library strategy", ["WGS", "AMPLICON", "RNA-Seq"], key="nc_strat")
            lsrc = c[1].selectbox("Library source", ["GENOMIC", "VIRAL RNA", "TRANSCRIPTOMIC", "METAGENOMIC"], key="nc_lsrc")
            lsel = c[2].selectbox("Library selection", ["RANDOM", "RT-PCR", "PCR", "cDNA"], key="nc_lsel")
            inst = c[3].text_input("Instrument model", placeholder="Illumina MiSeq", key="nc_inst")
            cand = core.ncbi_candidates(run, srcname, maxn)
            st.write("Tick the sequences to include and set their IDs / per-sequence modifiers:")
            edited = st.data_editor(pd.DataFrame(cand), hide_index=True, width="stretch", key="nc_table",
                                    disabled=["original_name", "length_after_trim", "N_percent"])
            if st.button("📦 Build NCBI files", type="primary", key="nc_go"):
                meta = dict(organism=organism, strain_or_isolate=strain, host=host, country=country, collection_date=date,
                            isolation_source=isosrc, bioproject=bioproj, name_field=namef, global_extra=gextra,
                            library_strategy=strat, library_source=lsrc, library_selection=lsel, instrument_model=inst)
                try:
                    inc, exc, files = core.build_ncbi_package(run, srcname, meta, edited.to_dict("records"), maxn)
                    st.success(f"{len(inc)} sequence(s) ready, {len(exc)} excluded.")
                    for e in exc: st.warning(f"{e['sequence']}: {e['reason']}")
                    st.session_state["ncbi_files"] = files
                except Exception as e:
                    st.error(str(e))
            for i, f in enumerate(st.session_state.get("ncbi_files", [])):
                dl(f"⬇ {Path(f).name}", f, f"dl_ncbi_{i}")
        st.divider()
        if st.button("🗜️ Build full results bundle (zip)", key="zip_go"):
            st.session_state["zip"] = core.make_bundle(run)
        if st.session_state.get("zip") and Path(st.session_state["zip"]).exists():
            dl("⬇ Download everything (zip)", st.session_state["zip"], "dl_zip", "application/zip")
