"""ngs_core.py – universal paired-end NGS analysis pipeline (no UI code).

QC/trimming -> de novo (SPAdes) and/or reference-guided (Bowtie2 + bcftools, iterative)
-> BLAST -> phylogeny + amino-acid changes -> Excel/figures -> NCBI submission package.
Designed for small genomes (viruses, plasmids, organelles, amplicons, gene segments, small bacterial genomes
for the assembly/mapping part).
"""
import io, os, re, sys, json, glob, shutil, subprocess, time, zipfile, base64
from pathlib import Path

IUPAC = set("ACGTRYSWKMBDHVN")
_COMP = str.maketrans("ACGTN", "TGCAN")

DEFAULT_PARAMS = dict(
    threads=4, adapter_file="TruSeq3-PE-2.fa", min_read_len=36, sample_type="RNA virus",
    min_depth=10, min_variant_qual=30, min_alt_fraction=0.5, ref_iterations=2,
    min_contig_len=200, min_contig_cov=5.0,
)

# ----------------------------------------------------------------------------- generic helpers
def sh(cmd, log=None, check=True, stream=None):
    """bash -c with pipefail. Streams lines to `stream` if given. Raises RuntimeError on failure."""
    p = subprocess.Popen(["bash", "-c", "set -o pipefail; " + cmd], stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT, text=True)
    lines = []
    for line in p.stdout:
        lines.append(line)
        if stream:
            stream(line.rstrip("\n"))
    p.wait()
    text = "".join(lines)
    if log:
        Path(log).parent.mkdir(parents=True, exist_ok=True)
        Path(log).write_text(text)
    if check and p.returncode != 0:
        tail = "\n".join(text.strip().splitlines()[-15:])
        raise RuntimeError(f"Command failed (exit {p.returncode}): {cmd[:300]}\n--- last output ---\n{tail}")
    return text

def which_any(*names):
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    return None

def avail_mem_gb():
    try:
        for l in open("/proc/meminfo"):
            if l.startswith("MemAvailable"):
                return max(2, int(int(l.split()[1]) / 1048576 * 0.8))
    except Exception:
        pass
    return 8

def parse_fasta(path):
    recs, name, seq = [], None, []
    for line in open(path):
        line = line.rstrip("\r\n")
        if line.startswith(">"):
            if name is not None:
                recs.append((name, "".join(seq)))
            name, seq = line[1:].strip(), []
        elif name is not None:
            seq.append(line.strip())
    if name is not None:
        recs.append((name, "".join(seq)))
    return recs

def write_fasta(recs, path, width=70):
    with open(path, "w") as f:
        for name, seq in recs:
            f.write(f">{name}\n")
            for i in range(0, len(seq), width):
                f.write(seq[i:i + width] + "\n")

def clean_reference(src, dst):
    text = open(src, errors="ignore").read().strip()
    if not text.startswith(">"):
        text = ">reference\n" + text
    tmp = str(dst) + ".raw"
    open(tmp, "w").write(text + "\n")
    recs, seen = [], {}
    for name, seq in parse_fasta(tmp):
        seq = re.sub(r"[\s\-\*]", "", seq).upper().replace("U", "T")
        seq = "".join(c if c in IUPAC else "N" for c in seq)
        if not seq:
            continue
        sid = re.sub(r"[^A-Za-z0-9_.|:-]", "_", name.split()[0]) or "ref"
        seen[sid] = seen.get(sid, 0) + 1
        if seen[sid] > 1:
            sid = f"{sid}_{seen[sid]}"
        recs.append((sid, seq))
    os.remove(tmp)
    if not recs:
        raise ValueError("No valid sequences found in the reference FASTA.")
    write_fasta(recs, dst)
    return recs

def find_pairs(folder):
    pairs = {}
    for f in sorted(glob.glob(os.path.join(folder, "*"))):
        b = os.path.basename(f)
        m = re.match(r"^(.*?)([_.-])R1((?:_\d+)?\.f(?:ast)?q(?:\.gz)?)$", b)
        if m:
            s, r2 = m.group(1), f"{m.group(1)}{m.group(2)}R2{m.group(3)}"
        else:
            m = re.match(r"^(.*?)_1(\.f(?:ast)?q(?:\.gz)?)$", b)
            if not m:
                continue
            s, r2 = m.group(1), f"{m.group(1)}_2{m.group(2)}"
        p2 = os.path.join(folder, r2)
        if os.path.exists(p2):
            pairs[s] = (f, p2)
    return pairs

def tool_status():
    jar = next(iter(sorted(glob.glob("/usr/share/java/trimmomatic*.jar"))), None)
    t = {"fastqc": which_any("fastqc"), "java": which_any("java"), "trimmomatic (jar)": jar,
         "spades": which_any("spades.py"), "bowtie2": which_any("bowtie2"), "samtools": which_any("samtools"),
         "bcftools": which_any("bcftools"), "quast (optional)": which_any("quast.py", "quast"),
         "mafft (phylogeny)": which_any("mafft"), "iqtree (phylogeny)": which_any("iqtree2", "iqtree"),
         "fasttree (phylogeny, fallback)": which_any("FastTree", "fasttree")}
    return t

# ----------------------------------------------------------------------------- run object
class Run:
    def __init__(self, path, data=None, logfn=None):
        self.dir = Path(path)
        self.data = data or {}
        self.logfn = logfn or (lambda m: None)

    def log(self, msg):
        self.logfn(msg)

    @property
    def params(self):
        return self.data["params"]

    @property
    def sample(self):
        return self.data["sample"]

    @property
    def results(self):
        d = self.dir / "results"
        d.mkdir(exist_ok=True)
        return d

    def save(self):
        (self.dir / "run.json").write_text(json.dumps(self.data, indent=1, default=str))

    def publish(self, path, newname=None):
        dst = self.results / (newname or Path(path).name)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(path, dst)
        return str(dst)

def new_run(base, sample, params, logfn=None):
    base = Path(base); base.mkdir(parents=True, exist_ok=True)
    rid = "run_" + time.strftime("%Y%m%d_%H%M%S")
    d = base / rid
    d.mkdir(parents=True, exist_ok=True)
    p = dict(DEFAULT_PARAMS); p.update(params or {})
    run = Run(d, {"run_id": rid, "sample": re.sub(r"[^A-Za-z0-9_.-]", "_", sample), "params": p}, logfn)
    run.save()
    return run

def load_run(path, logfn=None):
    path = Path(path)
    return Run(path, json.loads((path / "run.json").read_text()), logfn)

def list_runs(base):
    base = Path(base)
    return sorted([p.name for p in base.glob("run_*") if (p / "run.json").exists()], reverse=True)

# ----------------------------------------------------------------------------- mapping / variants
def map_reads(ref, r1, r2, prefix, threads=4):
    sh(f"bowtie2-build --threads {threads} -q {ref} {prefix}_idx")
    sh(f"bowtie2 --very-sensitive-local --no-unal -p {threads} -x {prefix}_idx -1 {r1} -2 {r2} "
       f"2> {prefix}_bowtie2.log | samtools sort -@ {threads} -o {prefix}.bam -")
    sh(f"samtools index {prefix}.bam && samtools faidx {ref}")
    log = open(f"{prefix}_bowtie2.log").read()
    m = re.search(r"([\d.]+)% overall alignment rate", log)
    mapped = int(sh(f"samtools view -c -F 4 {prefix}.bam").strip() or 0)
    return {"bam": f"{prefix}.bam", "overall_alignment_rate": float(m.group(1)) if m else None, "mapped_reads": mapped}

def depth_by_contig(bam, ref):
    depths = {n: [0] * len(s) for n, s in parse_fasta(ref)}
    for line in sh(f"samtools depth -a -J -q 20 -Q 20 {bam}").splitlines():
        c, p, d = line.split("\t")
        if c in depths:
            depths[c][int(p) - 1] = int(d)
    return depths

def write_mask(depths, min_depth, path):
    with open(path, "w") as f:
        for cid, arr in depths.items():
            start = None
            for i, d in enumerate(arr):
                if d < min_depth:
                    if start is None:
                        start = i
                elif start is not None:
                    f.write(f"{cid}\t{start}\t{i}\n"); start = None
            if start is not None:
                f.write(f"{cid}\t{start}\t{len(arr)}\n")

def call_variants(ref, bam, prefix, P):
    vcf = f"{prefix}.vcf.gz"
    sh(f"bcftools mpileup -Ou -f {ref} -a FORMAT/AD,FORMAT/DP -d 100000 -L 100000 -q 20 -Q 20 {bam} "
       f"| bcftools call --ploidy 1 -mv -Ou | bcftools norm -f {ref} -m -any -Ou "
       f"| bcftools filter -i 'QUAL>={P['min_variant_qual']} && FMT/DP>={P['min_depth']} && "
       f"FMT/AD[0:1]/FMT/DP>={P['min_alt_fraction']}' -Oz -o {vcf}")
    sh(f"bcftools index -f {vcf}")
    return vcf

def read_variants(vcf):
    txt = sh(f"bcftools query -f '%CHROM\\t%POS\\t%REF\\t%ALT\\t%QUAL\\t[%DP\\t%AD]\\n' {vcf}")
    rows = []
    for l in txt.strip().splitlines():
        c, p, r, a, q, dp, ad = l.split("\t")
        ad = [int(x) for x in ad.split(",") if x.isdigit()]
        af = round(ad[1] / int(dp), 3) if len(ad) > 1 and int(dp) else None
        typ = "SNP" if len(r) == 1 and len(a) == 1 else ("INS" if len(a) > len(r) else "DEL")
        rows.append({"contig": c, "pos": int(p), "ref": r, "alt": a, "type": typ, "qual": float(q),
                     "depth": int(dp), "alt_fraction": af})
    return rows

def apply_variants(ref, vcf, out, mask=None):
    m = f"-m {mask}" if mask else ""
    sh(f"bcftools consensus -H 1 {m} -f {ref} {vcf} > {out}")

def summarize_records(fasta, depths, min_depth):
    rows = []
    for name, seq in parse_fasta(fasta):
        d = depths.get(name) or []
        n = seq.count("N")
        rows.append({"id": name, "length": len(seq), "N_count": n, "N_percent": round(100 * n / max(len(seq), 1), 2),
                     "other_IUPAC": sum(1 for c in seq if c not in "ACGTN"),
                     "mean_depth": round(sum(d) / len(d), 1) if d else 0, "min_depth": min(d) if d else 0,
                     f"pct_cov_>={min_depth}x": round(100 * sum(1 for x in d if x >= min_depth) / len(d), 2) if d else 0})
    return rows

# ----------------------------------------------------------------------------- step: QC + trimming
def _parse_fastqc_zip(z):
    with zipfile.ZipFile(z) as zf:
        summ = next(n for n in zf.namelist() if n.endswith("summary.txt"))
        data = next(n for n in zf.namelist() if n.endswith("fastqc_data.txt"))
        status = {}
        for l in zf.read(summ).decode().strip().splitlines():
            s, m, _ = l.split("\t"); status[m] = s
        info = {}
        for l in zf.read(data).decode().splitlines():
            for key in ("Total Sequences", "Sequence length", "%GC"):
                if l.startswith(key + "\t"):
                    info[key] = l.split("\t")[1]
    return {"file": os.path.basename(z).replace("_fastqc.zip", ""), "total_sequences": info.get("Total Sequences"),
            "length": info.get("Sequence length"), "gc": info.get("%GC"), "status": status}

def _find_adapter(name, run):
    hits = glob.glob(f"/usr/share/trimmomatic/{name}") + glob.glob(f"/usr/share/**/{name}", recursive=True)
    if hits:
        return hits[0]
    dst = run.dir / f"adapters_{name}"
    import urllib.request
    urllib.request.urlretrieve(f"https://raw.githubusercontent.com/usadellab/Trimmomatic/main/adapters/{name}", dst)
    return str(dst)

def step_qc_trim(run, r1_raw, r2_raw, reference=None):
    P, D = run.params, run.dir
    for sub in ("qc_raw", "qc_trimmed", "trimmed", "logs"):
        (D / sub).mkdir(exist_ok=True)
    run.data.update({"r1_raw": str(r1_raw), "r2_raw": str(r2_raw), "reference": reference})

    def fastqc(files, outdir):
        sh(f"fastqc -q -t {P['threads']} -o {outdir} " + " ".join(f"'{f}'" for f in files),
           log=D / "logs" / f"fastqc_{Path(outdir).name}.log", check=False)
        return [_parse_fastqc_zip(z) for z in sorted(glob.glob(f"{outdir}/*_fastqc.zip"))]

    run.log("FastQC on raw reads ...")
    run.data["qc_raw"] = fastqc([r1_raw, r2_raw], D / "qc_raw")
    run.log("Trimmomatic ...")
    jar = next(iter(sorted(glob.glob("/usr/share/java/trimmomatic*.jar"))), None)
    if not jar:
        raise RuntimeError("Trimmomatic jar not found (install the 'trimmomatic' package).")
    adapter = _find_adapter(P["adapter_file"], run)
    S, T = run.sample, D / "trimmed"
    o1p, o1u, o2p, o2u = (T / f"{S}_R1_paired.fastq.gz", T / f"{S}_R1_unpaired.fastq.gz",
                          T / f"{S}_R2_paired.fastq.gz", T / f"{S}_R2_unpaired.fastq.gz")
    txt = sh(f"java -jar {jar} PE -threads {P['threads']} -phred33 '{r1_raw}' '{r2_raw}' {o1p} {o1u} {o2p} {o2u} "
             f"ILLUMINACLIP:{adapter}:2:30:10:2:True LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:{P['min_read_len']}",
             log=D / "logs" / "trimmomatic.log")
    m = re.search(r"Input Read Pairs: (\d+) Both Surviving: (\d+) \(([\d.]+)%\) Forward Only Surviving: (\d+) \(([\d.]+)%\) "
                  r"Reverse Only Surviving: (\d+) \(([\d.]+)%\) Dropped: (\d+) \(([\d.]+)%\)", txt)
    if not m:
        raise RuntimeError("Could not parse Trimmomatic output:\n" + txt[-800:])
    g = m.groups()
    run.data["trim"] = {"input_pairs": int(g[0]), "both_surviving": int(g[1]), "both_surviving_pct": float(g[2]),
                        "forward_only": int(g[3]), "reverse_only": int(g[5]), "dropped": int(g[7]), "dropped_pct": float(g[8])}
    if run.data["trim"]["both_surviving"] == 0:
        raise RuntimeError("Trimmomatic kept 0 read pairs – check adapter choice / read quality.")
    run.data["r1_trim"], run.data["r2_trim"] = str(o1p), str(o2p)
    run.log("FastQC on trimmed reads ...")
    run.data["qc_trim"] = fastqc([o1p, o2p], D / "qc_trimmed")
    run.save()

# ----------------------------------------------------------------------------- step: de novo
def step_denovo(run):
    P, D, S = run.params, run.dir, run.sample
    DN = D / "denovo"; DN.mkdir(exist_ok=True)
    out = DN / "spades"
    base = (f"spades.py -1 {run.data['r1_trim']} -2 {run.data['r2_trim']} -o {out} -t {P['threads']} -m {avail_mem_gb()}")
    help_txt = sh("spades.py --help", check=False)
    flag = {"RNA virus": "--rnaviral", "DNA virus / bacterium / isolate": "--isolate",
            "Metagenome / mixed sample": "--meta", "General (careful)": "--careful"}.get(P["sample_type"], "--careful")
    attempts = []
    if flag in help_txt:
        attempts.append((flag.strip("-"), f"{base} {flag}"))
    attempts.append(("careful", f"{base} --careful"))
    used = None
    for mode, cmd in attempts:
        run.log(f"SPAdes ({mode}) ...")
        shutil.rmtree(out, ignore_errors=True)
        try:
            sh(cmd, log=D / "logs" / f"spades_{mode}.log")
        except RuntimeError as e:
            run.log(f"  {mode} failed: {str(e).splitlines()[0][:120]}")
            continue
        if (out / "contigs.fasta").exists() and (out / "contigs.fasta").stat().st_size > 0:
            used = mode; break
    if not used:
        raise RuntimeError(f"SPAdes produced no contigs. See {D}/logs/spades_*.log")

    rows, keep = [], []
    for name, seq in parse_fasta(out / "contigs.fasta"):
        m = re.match(r"NODE_(\d+)_length_(\d+)_cov_([\d.]+)", name)
        L, cov = (int(m.group(2)), float(m.group(3))) if m else (len(seq), 0.0)
        ok = L >= P["min_contig_len"] and cov >= P["min_contig_cov"]
        rows.append({"spades_id": name, "length": L, "kmer_coverage": cov, "kept": ok})
        if ok:
            keep.append((name, seq, cov))
    keep.sort(key=lambda r: -len(r[1]))
    if not keep:
        raise RuntimeError("All contigs were filtered out – lower the minimum contig length / coverage.")
    recs = [(f"{S}_contig{i}_len{len(s)}_cov{c:.1f}", s) for i, (n, s, c) in enumerate(keep, 1)]
    final = DN / f"{S}_denovo_consensus.fasta"
    write_fasta(recs, final)
    write_fasta(recs[:1], DN / f"{S}_denovo_longest_contig.fasta")
    run.log("Mapping reads back to contigs (validation) ...")
    mp = map_reads(str(final), run.data["r1_trim"], run.data["r2_trim"], str(DN / "backmap"), P["threads"])
    depths = depth_by_contig(mp["bam"], str(final))
    json.dump(depths, open(DN / "depth.json", "w"))
    quast_rows = []
    quast = which_any("quast.py", "quast")
    if quast:
        run.log("QUAST ...")
        ref = f"-r {run.data['reference']}" if run.data.get("reference") else ""
        try:
            sh(f"{quast} {final} {ref} -o {DN/'quast'} -t {P['threads']} --min-contig 0 --no-icarus --silent",
               log=D / "logs" / "quast.log")
            for l in open(DN / "quast" / "report.tsv").read().strip().splitlines():
                k, *v = l.split("\t"); quast_rows.append({"metric": k, "value": v[0] if v else ""})
        except Exception as e:
            run.log(f"  QUAST failed (non-fatal): {str(e).splitlines()[0][:120]}")
    run.data["denovo"] = {"mode": used, "contigs_table": rows, "n_kept": len(recs), "consensus": str(final),
                          "mapping": mp, "records": summarize_records(str(final), depths, P["min_depth"]),
                          "depth_json": str(DN / "depth.json"), "quast": quast_rows,
                          "published": [run.publish(final), run.publish(DN / f"{S}_denovo_longest_contig.fasta")]}
    run.save()

# ----------------------------------------------------------------------------- step: reference-guided
def step_refguided(run):
    P, D, S = run.params, run.dir, run.sample
    if not run.data.get("reference"):
        raise RuntimeError("Reference-guided workflow needs a reference FASTA.")
    RG = D / "refguided"; RG.mkdir(exist_ok=True)
    r1, r2, T = run.data["r1_trim"], run.data["r2_trim"], P["threads"]
    ref0 = str(RG / "ref_round0.fasta"); shutil.copy(run.data["reference"], ref0)
    ref_cur, iters, last, first_vars = ref0, [], None, []
    for it in range(1, max(1, P["ref_iterations"]) + 1):
        run.log(f"Reference-guided round {it}: mapping + variant calling ...")
        pref = str(RG / f"round{it}")
        mp = map_reads(ref_cur, r1, r2, pref, T)
        vcf = call_variants(ref_cur, mp["bam"], pref, P)
        vars_ = read_variants(vcf)
        if it == 1:
            first_vars = vars_
        iters.append({"round": it, "alignment_rate_pct": mp["overall_alignment_rate"], "mapped_reads": mp["mapped_reads"],
                      "variants_applied": len(vars_)})
        last = (ref_cur, mp["bam"], vcf)
        if len(vars_) == 0 or it >= P["ref_iterations"]:
            break
        nxt = str(RG / f"round{it}_unmasked.fasta")
        apply_variants(ref_cur, vcf, nxt)
        ref_cur = nxt
    ref_used, bam, vcf = last
    run.log("Masking low-coverage positions and building final consensus ...")
    depths_used = depth_by_contig(bam, ref_used)
    write_mask(depths_used, P["min_depth"], str(RG / "lowcov_mask.bed"))
    raw_out = str(RG / "consensus_raw.fasta")
    apply_variants(ref_used, vcf, raw_out, mask=str(RG / "lowcov_mask.bed"))
    final = RG / f"{S}_refguided_consensus.fasta"
    named = [(f"{S}|{n}|ref-guided", s) for n, s in parse_fasta(raw_out)]
    write_fasta(named, final)
    run.log("Verification: re-mapping reads to the final consensus ...")
    vref = str(RG / "verify_ref.fasta"); write_fasta(named, vref)
    vmp = map_reads(vref, r1, r2, str(RG / "verify"), T)
    vdepths = depth_by_contig(vmp["bam"], vref)
    json.dump(vdepths, open(RG / "depth.json", "w"))
    residual = read_variants(call_variants(vref, vmp["bam"], str(RG / "verify"), P))
    shutil.copy(vcf, RG / f"{S}_final_round_variants.vcf.gz")
    run.data["refguided"] = {"iterations": iters, "consensus": str(final),
                             "records": summarize_records(str(final), vdepths, P["min_depth"]),
                             "variants_vs_reference": first_vars, "residual_variants": residual, "verify_mapping": vmp,
                             "depth_json": str(RG / "depth.json"),
                             "published": [run.publish(final), run.publish(RG / f"{S}_final_round_variants.vcf.gz")]}
    run.save()

# ----------------------------------------------------------------------------- step: BLAST
def _parse_blast_record(rec, workflow, qname, qlen, top):
    rows = []
    for rank, aln in enumerate(rec.alignments[:top], 1):
        best = max(aln.hsps, key=lambda h: h.bits)
        ivs = sorted((min(h.query_start, h.query_end), max(h.query_start, h.query_end)) for h in aln.hsps)
        covered, cs, ce = 0, None, None
        for a, b in ivs:
            if ce is None or a > ce + 1:
                if ce is not None:
                    covered += ce - cs + 1
                cs, ce = a, b
            else:
                ce = max(ce, b)
        if ce is not None:
            covered += ce - cs + 1
        title = re.sub(r"^(gi\|\d+\|)?[a-z]+\|[^|]+\|\s*", "", aln.title)
        rows.append({"workflow": workflow, "query": qname, "query_len": qlen, "rank": rank, "accession": aln.accession,
                     "description": title[:120], "identity_pct": round(100 * best.identities / best.align_length, 2),
                     "query_cov_pct": round(100 * covered / max(qlen, 1), 1), "align_len": best.align_length,
                     "mismatches": best.align_length - best.identities - best.gaps, "gaps": best.gaps,
                     "evalue": best.expect, "bitscore": round(best.bits, 1)})
    return rows

def consensus_queries(run, sources):
    q = []
    for key, label in (("refguided", "reference-guided"), ("denovo", "de novo")):
        if key in sources and key in run.data:
            for name, seq in parse_fasta(run.data[key]["consensus"]):
                q.append((key, label, name, seq.strip("N")))
    return q

def step_blast(run, sources=("refguided", "denovo"), database="nt", entrez_query="", top_hits=10,
               max_query_len=30000, max_queries=20):
    from Bio.Blast import NCBIWWW, NCBIXML
    queries = sorted(consensus_queries(run, sources), key=lambda x: -len(x[3]))[:max_queries]
    if not queries:
        raise RuntimeError("No consensus sequences available – run an assembly workflow first.")
    rows, errors = [], []
    for key, label, name, seq in queries:
        if len(seq.replace("N", "")) < 50:
            errors.append(f"{name}: fewer than 50 non-N bases, skipped"); continue
        q = seq[:max_query_len]
        run.log(f"BLAST [{label}] {name} ({len(q)} bp) ...")
        done, last = False, ""
        for attempt in (1, 2):
            try:
                h = NCBIWWW.qblast("blastn", database, q, megablast=True, hitlist_size=top_hits,
                                   entrez_query=entrez_query.strip() or "(none)")
                got = _parse_blast_record(NCBIXML.read(h), label, name, len(q), top_hits)
                if not got:
                    errors.append(f"{name}: no hits returned")
                rows += got; done = True; break
            except Exception as e:
                last = str(e)
                run.log(f"  attempt {attempt} failed: {last[:120]}")
        if not done:
            errors.append(f"{name}: BLAST failed ({last[:150]})")
    run.data["blast"] = {"rows": rows, "errors": errors, "database": database, "entrez_query": entrez_query}
    if rows:
        import pandas as pd
        tsv = run.dir / f"{run.sample}_blast_results.tsv"
        pd.DataFrame(rows).to_csv(tsv, sep="\t", index=False)
        run.publish(tsv)
    run.save()

# ----------------------------------------------------------------------------- step: phylogeny + mutations
def parse_markers(text):
    """lines: gene_keyword|alt_keyword ; position ; concerning_aa ; note"""
    rows = []
    for line in (text or "").splitlines():
        p = [x.strip() for x in line.split(";")]
        if len(p) >= 3 and p[1].isdigit() and p[2]:
            rows.append(([k.strip().lower() for k in p[0].split("|") if k.strip()], int(p[1]), p[2].upper(),
                         p[3] if len(p) > 3 else ""))
    return rows

def _safe_label(t):
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", t).strip("_")[:60]

def _tr(codon):
    from Bio.Seq import Seq
    if len(codon) < 3 or any(c not in "ACGT" for c in codon):
        return "X"
    return str(Seq(codon).translate())

def _gene_matches(gene, prod, kws):
    text = f"{gene} {prod}".lower()
    return any(re.search(r"(^|[^a-z0-9])" + re.escape(k) + r"([^a-z0-9]|$)", text) for k in kws)

def _kmers(s, k=12):
    s = s.upper()
    return {s[i:i + k] for i in range(len(s) - k + 1) if "N" not in s[i:i + k]}

def _similarity(a, b):
    A = _kmers(a); B = _kmers(b) | _kmers(b.translate(_COMP)[::-1])
    return len(A & B) / max(1, min(len(A), len(B)))

def _strain_of(rec):
    for f in rec.features:
        if f.type == "source":
            for k in ("strain", "isolate"):
                if k in f.qualifiers:
                    return f.qualifiers[k][0]
    return rec.description[:40]

def _fetch_gb(accs, run):
    from Bio import Entrez, SeqIO
    out, accs = {}, list(dict.fromkeys(a.strip() for a in accs if a.strip()))
    for i in range(0, len(accs), 20):
        batch, err = accs[i:i + 20], None
        for attempt in range(3):
            try:
                h = Entrez.efetch(db="nuccore", id=",".join(batch), rettype="gb", retmode="text")
                for rec in SeqIO.parse(h, "genbank"):
                    out[rec.id.split(".")[0]] = rec
                err = None; break
            except Exception as e:
                err = e; time.sleep(3 * (attempt + 1))
        if err:
            run.log(f"  GenBank fetch failed for {batch[:3]}...: {str(err)[:100]}")
        time.sleep(0.4)
    return out

def _mafft(records, out_path):
    inp = str(out_path) + ".in.fasta"
    write_fasta(records, inp)
    sh(f"{which_any('mafft')} --auto --adjustdirection --quiet {inp} > {out_path}")

def _build_tree(aln, prefix, method, boots, run):
    if len(parse_fasta(aln)) < 4:
        return None, "fewer than 4 sequences – tree skipped"
    iq, ft = which_any("iqtree2", "iqtree"), which_any("FastTree", "fasttree")
    if iq and method == "iqtree":
        try:
            sh(f"{iq} -s {aln} -m MFP -bb {max(1000, boots)} -redo -pre {prefix}", log=f"{prefix}.log")
            return f"{prefix}.treefile", "IQ-TREE (ModelFinder, UFBoot)"
        except RuntimeError as e:
            run.log(f"  IQ-TREE failed, using FastTree: {str(e).splitlines()[0][:100]}")
    if ft:
        sh(f"{ft} -quiet -nt -gtr {aln} > {prefix}.nwk")
        return f"{prefix}.nwk", "FastTree (GTR, SH-like support)"
    return None, "no tree program available"

def _draw_tree(treefile, qlabel, title, png):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from Bio import Phylo
    t = Phylo.read(treefile, "newick")
    try:
        t.root_at_midpoint()
    except Exception:
        pass
    fig = plt.figure(figsize=(9, 0.4 * t.count_terminals() + 1.8)); ax = fig.add_subplot(1, 1, 1)
    def tip(c): return c.name if c.is_terminal() else None
    def sup(c):
        if c.is_terminal() or c.confidence is None:
            return None
        return f"{c.confidence:.0f}" if c.confidence > 1 else f"{c.confidence * 100:.0f}"
    Phylo.draw(t, axes=ax, do_show=False, label_func=tip, branch_labels=sup,
               label_colors=lambda l: "red" if l == qlabel else "black")
    ax.set_title(title, fontsize=10); ax.set_yticks([]); ax.set_ylabel("")
    for sp in ("top", "right", "left"):
        ax.spines[sp].set_visible(False)
    ax.set_xlabel("substitutions / site (node labels = bootstrap support)")
    fig.tight_layout(); fig.savefig(png, dpi=200, facecolor="white"); plt.close(fig)

def _analyze_mutations(run, qname, qseq, hit_rec, tag, markers, PH):
    ref = str(hit_rec.seq).upper()
    inp, out = PH / f"{tag}_pair.in.fasta", PH / f"{tag}_pair.aln.fasta"
    write_fasta([("ref", ref), ("query", qseq.upper())], inp)
    sh(f"{which_any('mafft')} --auto --adjustdirection --quiet {inp} > {out}")
    al = parse_fasta(out); a_r, a_q = al[0][1].upper(), al[1][1].upper()
    cols = [i for i, c in enumerate(a_r) if c != "-"]
    pairs = [(x, y) for x, y in zip(a_q, a_r) if x in "ACGT" and y in "ACGT"]
    ident = round(100 * sum(x == y for x, y in pairs) / max(len(pairs), 1), 2)
    subs, genes, mk = [], [], []
    for feat in hit_rec.features:
        if feat.type != "CDS":
            continue
        parts = list(feat.location.parts)
        if any(p.strand == -1 for p in parts):
            continue
        gene = feat.qualifiers.get("gene", [""])[0]; prod = feat.qualifiers.get("product", [""])[0]
        pos = [p for part in parts for p in range(int(part.start), int(part.end))]
        if len(pos) < 3:
            continue
        rcds = "".join(ref[p] for p in pos); qcds = "".join(a_q[cols[p]] for p in pos)
        rprot, qprot, nd = [], [], 0
        for i in range(0, len(pos) - 2, 3):
            rc, qc = rcds[i:i + 3], qcds[i:i + 3]; ra, qa = _tr(rc), _tr(qc)
            rprot.append(ra); qprot.append(qa)
            if ra != "X" and qa != "X" and ra != qa:
                nd += 1
                subs.append({"query": qname, "gene": gene, "product": prod, "aa_pos": i // 3 + 1, "ref_aa": ra, "sample_aa": qa,
                             "ref_codon": rc, "sample_codon": qc, "reference": hit_rec.id})
        genes.append({"query": qname, "gene": gene, "product": prod, "protein_len_aa": len(qprot), "aa_differences": nd,
                      "unresolved_aa(X)": qprot.count("X"), "aa_identity_pct": round(100 * (1 - nd / max(len(qprot), 1)), 2),
                      "reference": hit_rec.id})
        for kws, mpos, bad, note in markers:
            if _gene_matches(gene, prod, kws) and mpos <= len(qprot):
                sa = qprot[mpos - 1]
                mk.append({"query": qname, "gene": gene or prod, "position": mpos, "reference_aa": rprot[mpos - 1], "sample_aa": sa,
                           "concerning_aa": bad, "status": "PRESENT" if sa == bad else ("unresolved" if sa == "X" else "absent"),
                           "note": note})
    return ident, subs, genes, mk

def step_phylo(run, sources=("refguided",), tree_method="iqtree", tree_hits=10, boots=1000, extra_accessions="",
               email="", api_key="", markers_text="", max_len=100000):
    from Bio import Entrez
    rows = (run.data.get("blast") or {}).get("rows")
    if not rows:
        raise RuntimeError("Run BLAST first – the BLAST hits are the comparison sequences.")
    if not which_any("mafft"):
        raise RuntimeError("MAFFT is not installed.")
    Entrez.email = email.strip() or "ngs.app.user@example.com"
    if api_key.strip():
        Entrez.api_key = api_key.strip()
    markers = parse_markers(markers_text)
    PH = run.dir / "phylo"; PH.mkdir(exist_ok=True)
    queries = [q for q in consensus_queries(run, sources)]
    skipped, queries2 = [], []
    for key, label, name, seq in queries:
        if len(seq) > max_len:
            skipped.append(f"{name}: {len(seq)} bp > {max_len} bp limit for alignment/phylogeny (skipped)")
        elif any(r["query"] == name for r in rows):
            queries2.append((key, name, seq))
    if not queries2:
        raise RuntimeError("No eligible sequences (need BLAST hits and length ≤ limit). " + " | ".join(skipped))
    need = [r["accession"] for r in rows if r["query"] in {q[1] for q in queries2} and r["rank"] <= tree_hits]
    extra = [a for a in re.split(r"[,\s;]+", extra_accessions) if a]
    run.log(f"Downloading {len(set(need))} BLAST-hit + {len(extra)} extra GenBank record(s) ...")
    recs = _fetch_gb(need + extra, run)
    extra_assign = {q[1]: [] for q in queries2}
    for a in extra:
        er = recs.get(a.split(".")[0])
        if not er:
            continue
        s_, qn = max((_similarity(q[2], str(er.seq)), q[1]) for q in queries2)
        if s_ >= 0.03:
            extra_assign[qn].append(er)
        else:
            run.log(f"  extra record {er.id} did not resemble any of your sequences – skipped")
    phylo = {"groups": [], "identity": [], "substitutions": [], "genes": [], "markers": [], "skipped": skipped}
    for key, qname, qseq in queries2:
        tag = _safe_label(qname)[:40]
        hits = [r for r in rows if r["query"] == qname and r["rank"] <= tree_hits]
        hit_recs = [recs[h["accession"].split(".")[0]] for h in hits if h["accession"].split(".")[0] in recs]
        hit_recs += [e for e in extra_assign[qname] if e.id not in {h.id for h in hit_recs}]
        hit_recs = [h for h in hit_recs if len(h.seq) <= max_len]
        if not hit_recs:
            phylo["skipped"].append(f"{qname}: no usable comparison records"); continue
        run.log(f"Phylogeny + mutations: {qname} ({len(hit_recs)} comparison sequences)")
        qlabel = "YOUR_" + _safe_label(qname)[:40]
        seqs, seen = [(qlabel, qseq)] + [(_safe_label(f"{h.id}_{_strain_of(h)}"), str(h.seq).upper()) for h in hit_recs], set()
        uniq = []
        for n, s_ in seqs:
            while n in seen:
                n += "_x"
            seen.add(n); uniq.append((n, s_))
        aln = PH / f"{tag}.aln.fasta"
        _mafft(uniq, aln)
        tfile, method = _build_tree(str(aln), str(PH / tag), tree_method, boots, run)
        png = None
        if tfile:
            png = str(PH / f"{tag}_tree.png")
            _draw_tree(tfile, qlabel, f"{qname}  –  {method}", png)
            run.publish(png, f"phylogeny/{Path(png).name}"); run.publish(tfile, f"phylogeny/{tag}.nwk")
        run.publish(aln, f"phylogeny/{aln.name}")
        ident, subs, genes, mk = _analyze_mutations(run, qname, qseq, hit_recs[0], tag, markers, PH)
        phylo["groups"].append({"query": qname, "workflow": key, "n_sequences": len(uniq), "method": method,
                                "tree_png": png, "tree_file": tfile, "alignment": str(aln), "best_hit": hit_recs[0].id})
        phylo["identity"].append({"query": qname, "reference": hit_recs[0].id, "reference_strain": _strain_of(hit_recs[0]),
                                  "nt_identity_pct": ident})
        phylo["substitutions"] += subs; phylo["genes"] += genes; phylo["markers"] += mk
    run.data["phylo"] = phylo
    run.save()

# ----------------------------------------------------------------------------- figures / excel / bundle
def depth_png(depths, title, min_depth, max_panels=12, dpi=110):
    import matplotlib; matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    items = sorted(depths.items(), key=lambda kv: -len(kv[1]))[:max_panels]
    if not items:
        return b""
    fig, axes = plt.subplots(len(items), 1, figsize=(11, 1.9 * len(items) + 0.8), squeeze=False)
    for ax, (cid, arr) in zip(axes[:, 0], items):
        ax.fill_between(range(1, len(arr) + 1), arr, step="mid", alpha=0.6)
        ax.axhline(min_depth, color="red", ls="--", lw=1)
        ax.set_yscale("symlog"); ax.set_ylabel("depth"); ax.set_title(cid, loc="left", fontsize=9)
        ax.set_xlim(1, max(len(arr), 2))
    axes[-1, 0].set_xlabel(f"position (red dashed = {min_depth}x threshold)")
    fig.suptitle(title); fig.tight_layout()
    buf = io.BytesIO(); fig.savefig(buf, format="png", dpi=dpi, facecolor="white"); plt.close(fig)
    return buf.getvalue()

def step_export_excel(run):
    import pandas as pd
    P, S = run.params, run.sample
    FIG = run.results / "figures"; FIG.mkdir(exist_ok=True)
    def flat_qc(rows):
        out = []
        for r in rows or []:
            d = {"file": r["file"], "total_sequences": r["total_sequences"], "length": r["length"], "gc_pct": r["gc"]}
            d.update(r["status"]); out.append(d)
        return out
    d = run.data
    sheets = {"Parameters": [{"parameter": k, "value": v} for k, v in P.items()] +
                            [{"parameter": "sample", "value": S}, {"parameter": "reference", "value": d.get("reference")}],
              "QC_raw": flat_qc(d.get("qc_raw")), "Trimming": [d.get("trim", {})], "QC_trimmed": flat_qc(d.get("qc_trim"))}
    for key, label in (("refguided", "RefGuided"), ("denovo", "DeNovo")):
        if key in d:
            png = depth_png(json.load(open(d[key]["depth_json"])), f"{label}: read depth", P["min_depth"], dpi=250)
            (FIG / f"{S}_coverage_{key}.png").write_bytes(png)
    if "refguided" in d:
        g = d["refguided"]
        sheets.update({"RefGuided_consensus": g["records"], "RefGuided_iterations": g["iterations"],
                       "Variants_vs_reference": g["variants_vs_reference"], "Residual_variants": g["residual_variants"]})
    if "denovo" in d:
        x = d["denovo"]
        sheets.update({"DeNovo_contigs": x["contigs_table"], "DeNovo_consensus": x["records"], "DeNovo_QUAST": x["quast"]})
    if d.get("blast"):
        sheets["BLAST"] = d["blast"]["rows"]
    if d.get("phylo"):
        p = d["phylo"]
        sheets.update({"NT_identity_best_hit": p["identity"], "AA_summary": p["genes"], "AA_changes": p["substitutions"],
                       "Marker_positions": p["markers"], "Trees": p["groups"]})
    xlsx = run.results / f"{S}_supplementary_tables.xlsx"
    with pd.ExcelWriter(xlsx, engine="openpyxl") as xw:
        for name, rows_ in sheets.items():
            df = pd.DataFrame(rows_) if rows_ else pd.DataFrame({"info": ["no data"]})
            df.to_excel(xw, sheet_name=name[:31], index=False)
            ws = xw.sheets[name[:31]]
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width = min(60, max(10, max(len(str(c.value or "")) for c in col[:50]) + 2))
    return str(xlsx)

def make_bundle(run):
    zp = run.dir / f"{run.sample}_results.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
        for pat in ("logs/*", "run.json", "qc_raw/*.html", "qc_trimmed/*.html", "denovo/quast/report.*"):
            for f in run.dir.glob(pat):
                if f.is_file():
                    z.write(f, f.relative_to(run.dir))
        for f in run.results.rglob("*"):
            if f.is_file():
                z.write(f, Path("results") / f.relative_to(run.results))
    return str(zp)

# ----------------------------------------------------------------------------- NCBI submission package
def ncbi_candidates(run, source, max_n_percent=5.0):
    key = {"reference_guided": "refguided", "de_novo": "denovo"}[source]
    if key not in run.data:
        raise RuntimeError(f"The {source} workflow has not been run.")
    rows = []
    for i, (name, seq) in enumerate(parse_fasta(run.data[key]["consensus"]), 1):
        s = seq.strip("N")
        npct = round(100 * s.count("N") / max(len(s), 1), 2)
        ok = len(s) >= 200 and npct <= max_n_percent
        rows.append({"original_name": name, "length_after_trim": len(s), "N_percent": npct, "include": ok,
                     "seq_id": f"{run.sample}_{i}"[:45], "extra_modifiers": ""})
    return rows

def build_ncbi_package(run, source, meta, table, max_n_percent=5.0):
    import pandas as pd
    key = {"reference_guided": "refguided", "de_novo": "denovo"}[source]
    missing = [k for k in ("organism", "strain_or_isolate", "host", "country", "collection_date") if not str(meta.get(k, "")).strip()]
    if missing:
        raise ValueError("Fill in required fields: " + ", ".join(missing))
    seqs = dict(parse_fasta(run.data[key]["consensus"]))
    label = meta.get("name_field", "strain")
    mods = lambda extra: (f"[organism={meta['organism']}] [{label}={meta['strain_or_isolate']}] [host={meta['host']}] "
                          f"[country={meta['country']}] [collection-date={meta['collection_date']}]"
                          + (f" [isolation-source={meta['isolation_source']}]" if meta.get("isolation_source") else "")
                          + "".join(f" [{l.strip()}]" for l in (meta.get("global_extra", "") + "\n" + (extra or "")).splitlines() if "=" in l))
    included, excluded, ids = [], [], set()
    for r in table:
        if not r.get("include"):
            excluded.append({"sequence": r["original_name"], "reason": "unticked by user / failed pre-check"}); continue
        s = seqs[r["original_name"]].strip("N").upper(); why = []
        sid = str(r["seq_id"]).strip()
        if len(s) < 200: why.append(f"only {len(s)} bp (GenBank minimum 200)")
        npct = 100 * s.count("N") / max(len(s), 1)
        if npct > max_n_percent: why.append(f"{npct:.1f}% N (> {max_n_percent}%)")
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,50}", sid): why.append("sequence ID must be 1–50 chars of letters, digits, _ . -")
        if sid in ids: why.append("duplicate sequence ID")
        if why:
            excluded.append({"sequence": r["original_name"], "reason": "; ".join(why)}); continue
        ids.add(sid); included.append({"id": sid, "seq": s, "extra": r.get("extra_modifiers", ""), "orig": r["original_name"]})
    if not included:
        raise ValueError("No sequence passed validation: " + "; ".join(f"{e['sequence']}: {e['reason']}" for e in excluded))
    OUT = run.results / "ncbi_submission"; OUT.mkdir(parents=True, exist_ok=True); S = run.sample
    with open(OUT / f"{S}_genbank_sequences.fasta", "w") as f:
        for i in included:
            f.write(f">{i['id']} {mods(i['extra'])}\n")
            for k in range(0, len(i["seq"]), 70):
                f.write(i["seq"][k:k + 70] + "\n")
    pd.DataFrame([{"Sequence_ID": i["id"], "Organism": meta["organism"], label.capitalize(): meta["strain_or_isolate"],
                   "Host": meta["host"], "Country": meta["country"], "Collection_date": meta["collection_date"],
                   "Isolation_source": meta.get("isolation_source", ""), "Extra": i["extra"]} for i in included]
                 ).to_csv(OUT / f"{S}_source_modifiers.tsv", sep="\t", index=False)
    pd.DataFrame([{"sample_name": S, "organism": meta["organism"], label: meta["strain_or_isolate"], "host": meta["host"],
                   "geo_loc_name": meta["country"], "collection_date": meta["collection_date"],
                   "isolation_source": meta.get("isolation_source", ""), "bioproject_accession": meta.get("bioproject", "")}]
                 ).to_csv(OUT / f"{S}_biosample_attributes.tsv", sep="\t", index=False)
    pd.DataFrame([{"bioproject_accession": meta.get("bioproject", ""), "sample_name": S, "library_ID": S,
                   "title": f"{meta.get('library_strategy', 'WGS')} of {meta['organism']} {meta['strain_or_isolate']}",
                   "library_strategy": meta.get("library_strategy", "WGS"), "library_source": meta.get("library_source", "GENOMIC"),
                   "library_selection": meta.get("library_selection", "RANDOM"), "library_layout": "paired",
                   "platform": "ILLUMINA", "instrument_model": meta.get("instrument_model", ""),
                   "design_description": "Paired-end Illumina sequencing; see manuscript methods", "filetype": "fastq",
                   "filename": os.path.basename(run.data["r1_raw"]), "filename2": os.path.basename(run.data["r2_raw"])}]
                 ).to_csv(OUT / f"{S}_sra_metadata.tsv", sep="\t", index=False)
    pd.DataFrame(excluded or [{"sequence": "-", "reason": "none excluded"}]).to_csv(OUT / f"{S}_excluded_sequences.tsv", sep="\t", index=False)
    (OUT / "README_submission.txt").write_text(f"""NCBI SUBMISSION PACKAGE – {S}
Generated by the NGS app. NOTHING HAS BEEN SUBMITTED. Submit at https://submit.ncbi.nlm.nih.gov/ with your own NCBI account.

FILES
 {S}_genbank_sequences.fasta   {len(included)} sequence(s) with source modifiers in the definition lines
 {S}_source_modifiers.tsv      the same metadata as a table
 {S}_biosample_attributes.tsv  starting point for BioSample (pick the matching package in the portal)
 {S}_sra_metadata.tsv          starting point for the SRA metadata sheet
 {S}_excluded_sequences.tsv    sequences that failed validation, with reasons

ORDER: 1) BioProject  2) BioSample  3) SRA (upload the ORIGINAL raw FASTQ: {os.path.basename(run.data['r1_raw'])}, {os.path.basename(run.data['r2_raw'])})
       4) GenBank (this FASTA)  5) cite all accessions in the Data Availability statement.
CHECK: NCBI templates / accepted modifier names change – compare with the portal's current instructions. The portal runs its own
validation. Consensus = majority allele; positions below {run.params['min_depth']}x depth are N-masked.
""")
    run.data["ncbi"] = {"included": [{k: v for k, v in i.items() if k != "seq"} for i in included], "excluded": excluded,
                        "dir": str(OUT)}
    run.save()
    return included, excluded, sorted(str(p) for p in OUT.glob("*"))
